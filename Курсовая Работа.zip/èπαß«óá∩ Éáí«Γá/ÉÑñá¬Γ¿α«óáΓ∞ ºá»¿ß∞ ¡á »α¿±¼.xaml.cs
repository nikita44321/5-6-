﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Курсовая_Работа
{
    /// <summary>
    /// Логика взаимодействия для Редактировать_запись_на_приём.xaml
    /// </summary>
    public partial class Редактировать_запись_на_приём : Window
    {
        private СтоматологияEntities _ef;
        private Appointment _appointment;
        private Записать_на_приём _window;
        private СтоматологияEntities ef;
        private Записать_на_приём записать_на_приём;
       // string message = "Вы действительно хотите удалить запись?";
       // MessageBoxButton buttons = MessageBoxButton.YesNo;
        //string result;

        public Редактировать_запись_на_приём(СтоматологияEntities ef, Записать_на_приём записать_на_приём)
        {
            
            this.ef = ef;
            this.записать_на_приём = записать_на_приём;
        }

        public Редактировать_запись_на_приём(СтоматологияEntities ef, object o, Записать_на_приём записать_на_приём)
        {
            InitializeComponent();
            _appointment = (o as Button).DataContext as Appointment;           
            _ef = ef;
            _window = записать_на_приём;

            date.Text = Convert.ToString(_appointment.date);
            
        }

        private void addd_Click(object sender, RoutedEventArgs e)
        {
            _appointment.date = Convert.ToDateTime(date.Text);

            _window.RefreshAppointment();

            _ef.SaveChanges();
        }

        private void remove_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Вы действительно хотите удалить запись?", "Подтверждение",
        MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {

                _ef.Appointment.Remove(_appointment);

                _ef.SaveChanges();
                _window.RefreshAppointment();
                this.Close();
                

            }
            
        }
    }
}
