﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Курсовая_Работа
{
    /// <summary>
    /// Логика взаимодействия для Добавление_Услуги.xaml
    /// </summary>
    public partial class Добавление_Услуги : Window
    {
        private СтоматологияEntities _ef;
        private Изм_услуг _window;
       

        public Добавление_Услуги(СтоматологияEntities стоматологияEntities, Изм_услуг изм_Услуг)
        {
            InitializeComponent();
            this._ef = стоматологияEntities;
            this._window = изм_Услуг;


        }

        

       
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void Добавить_Click(object sender, RoutedEventArgs e)
        {
            _ef.Service.Add(new Service()
            {
                Name = TxtNameSr.Text,
                price = TxtPriceSr.Text,
                description = TxtDescriptionSr.Text

            });
            _ef.SaveChanges();
            _window.RefreshService();
            this.Close();
        }
    }
}
