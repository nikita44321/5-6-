﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Курсовая_Работа
{
    /// <summary>
    /// Логика взаимодействия для Записаться_на_приём.xaml
    /// </summary>
    public partial class Записаться_на_приём : Window
    {
        private List<Doctor> _doctor = new List<Doctor>();
        private List<Service> _service = new List<Service>();
        private List<Client> _client = new List<Client>();
        private Window _window;
        private СтоматологияEntities ef;
        private Записать_на_приём записать_на_приём;

        //private СтоматологияEntities ef1;
        //private Главная главная;

        // private string _SelectedDoctor;
        // private string _FindedName;

        public Записаться_на_приём(СтоматологияEntities стоматологияEntities, Записаться_на_приём_или_посмотреть_мои_записи записаться_на_приём_или_посмотреть_мои_записи)
        {
            InitializeComponent();
            InitForm(записаться_на_приём_или_посмотреть_мои_записи);

        }

        private void InitForm(Window записаться_на_приём_или_посмотреть_мои_записи)
        {
            List<Doctor> doctors = new List<Doctor>();
            doctors.Add(new Doctor() { Name = "Врач" });
            doctors.AddRange(СтоматологияEntities.GetContext().Doctor.OrderBy(d => d.Name).ToList());
            ComboBox.ItemsSource = doctors;

            List<Service> Services = new List<Service>();
            Services.Add(new Service() { Name = "Услуга" });
            Services.AddRange(СтоматологияEntities.GetContext().Service.OrderBy(d => d.Name).ToList());
            ComboBox1.ItemsSource = Services;

            List<Client> _client = new List<Client>();
            _client.Add(new Client() { Name = "Клиент" });
            _client.AddRange(СтоматологияEntities.GetContext().Client.OrderBy(d => d.Name).ToList());

            List<Client> _client1 = new List<Client>();
            _client1.Add(new Client() { Name = "Телефон" });
            _client1.AddRange(СтоматологияEntities.GetContext().Client.OrderBy(d => d.telephone).ToList());

            CbClient.ItemsSource = СтоматологияEntities.GetContext().Client.ToList();
            this._window = записаться_на_приём_или_посмотреть_мои_записи;
        }

        public Записаться_на_приём(СтоматологияEntities ef, Записать_на_приём записать_на_приём)
        {
            InitializeComponent();
            this.ef = ef;
            this.записать_на_приём = записать_на_приём;

            InitForm(записать_на_приём);
        }

        /* public Записаться_на_приём(СтоматологияEntities ef1, Главная главная)
         {
             this.ef1 = ef1;
             this.главная = главная;
         }*/

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ComboBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            СтоматологияEntities.GetContext().Appointment.Add(new Appointment() { date = Convert.ToDateTime(data.Text), Service = ComboBox1.SelectedItem as Service, Doctor = ComboBox.SelectedItem as Doctor, ID_Doctor = (ComboBox.SelectedItem as Doctor).ID_doctor, Client = CbClient.SelectedItem as Client, IsFree = true, ID_Service = (ComboBox1.SelectedItem as Service).ID });
            СтоматологияEntities.GetContext().SaveChanges();
            //_window.RefreshAppointment();
            this.Close();
        }

        private void client_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void telephone_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
