﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Курсовая_Работа
{
    /// <summary>
    /// Логика взаимодействия для Главная_Админ_.xaml
    /// </summary>
    public partial class Главная_Админ_ : Window
    {
        public Главная_Админ_()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow pg = new MainWindow();
            pg.Show();
            this.Hide();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Добавление_клиента pg = new Добавление_клиента();
            pg.Show();
            this.Hide();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Изм_услуг pg = new Изм_услуг();
            pg.Show();
            this.Hide();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Изменение_данных_врачей pg = new Изменение_данных_врачей();
            pg.Show();
            this.Hide();
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            Записать_на_приём pg = new Записать_на_приём();
            pg.Show();
            this.Hide();
        }
    }
}
