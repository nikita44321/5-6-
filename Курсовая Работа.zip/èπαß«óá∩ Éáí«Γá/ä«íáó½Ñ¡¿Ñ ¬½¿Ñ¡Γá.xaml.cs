﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Курсовая_Работа
{
    /// <summary>
    /// Логика взаимодействия для Добавление_клиента.xaml
    /// </summary>
    public partial class Добавление_клиента : Window
    {
        public static СтоматологияEntities ef = new СтоматологияEntities();
       
        private int _currentPage = 1;
        private int _maxPage = 0;
        private СтоматологияEntities _ef;
        public Добавление_клиента()

        {
            InitializeComponent();
           DataGridClient.ItemsSource = ef.Client.ToList();
            _ef = ef;
            
            //RefreshClient();
        }

        public void RefreshClient()
        {
            DataGridClient.ItemsSource = _ef.Client.OrderBy(h => h.Name).ToList();
            _maxPage = Convert.ToInt32(Math.Ceiling(_ef.Client.ToList().Count *1.0 / 10));
            var listClient = _ef.Client.ToList().Skip((_currentPage - 1) * 10).Take(10).ToList();
            LblTotalPages.Content = "of" + _maxPage.ToString();
            TxtCurrentPageNumber.Text = _currentPage.ToString();
            DataGridClient.ItemsSource = listClient;
        }
        
        private void BtnEditClientinfo_Click(object sender, RoutedEventArgs e)
        {
            Редактировать редактировать = new Редактировать(_ef, sender, this);
            редактировать.ShowDialog();
        }

        private void TxtCurrentPageNumber_TextChanged(object sender, TextChangedEventArgs e)
        {
            if(_currentPage>0 && _currentPage< _maxPage && TxtCurrentPageNumber.Text != "")
            {
                _currentPage = Convert.ToInt32(TxtCurrentPageNumber.Text);
                //RefreshClient();
            }
        }

        private void GoFirstPageButton_Click(object sender, RoutedEventArgs e)
        {
            _currentPage = 1;
           // RefreshClient();
        }

        private void GoPrevPageButton_Click(object sender, RoutedEventArgs e)
        {
            if(_currentPage-1<1)
            {
                return ;
            }
            _currentPage = _currentPage - 1;
            //RefreshClient();
        }

        private void GoNextPageButton_Click(object sender, RoutedEventArgs e)
        {
            if (_currentPage + 1 < _maxPage)
            {
                return;
            }
            _currentPage = _currentPage + 1;
//RefreshClient();
        }

        private void GoLastPageButton_Click(object sender, RoutedEventArgs e)
        {
            _currentPage = _maxPage;
           // RefreshClient();
        }

        private void BtnAddClient_Click(object sender, RoutedEventArgs e)
        {
            Добавить_Клиента добавить_Клиента = new Добавить_Клиента(_ef, this);
            добавить_Клиента.ShowDialog();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Главная_Админ_ pg = new Главная_Админ_();
            pg.Show();
            this.Hide();

        }
    }
}
