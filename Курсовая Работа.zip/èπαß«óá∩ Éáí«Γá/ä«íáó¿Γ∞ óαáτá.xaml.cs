﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Курсовая_Работа
{
    /// <summary>
    /// Логика взаимодействия для Добавить_врача.xaml
    /// </summary>
    public partial class Добавить_врача : Window
    {
        private СтоматологияEntities _ef;
        private Изменение_данных_врачей _window;
        public Добавить_врача(СтоматологияEntities стоматологияEntities, Изменение_данных_врачей изменение_Данных_Врачей)
        {
            InitializeComponent();
            this._ef = стоматологияEntities;
            this._window = изменение_Данных_Врачей;
        }

        private void Добавить_Click(object sender, RoutedEventArgs e)
        {
            _ef.Doctor.Add(new Doctor()
            {
                Name = TxtNameDc.Text,
                telephone = TxtPhoneDc.Text,
                specialty = TxtSpecialtyDc.Text

            });
            _ef.SaveChanges();
            _window.RefreshDoctor();
            this.Close();
        }
    }
}
