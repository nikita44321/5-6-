﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Курсовая_Работа
{
    /// <summary>
    /// Логика взаимодействия для Редактировать_изменение_данных_врачей.xaml
    /// </summary>
    public partial class Редактировать_изменение_данных_врачей : Window
    {
        private СтоматологияEntities _ef;
        private Doctor _doctor;
        private Изменение_данных_врачей _window;
        
  
   
        public Редактировать_изменение_данных_врачей(СтоматологияEntities ef, object o, Изменение_данных_врачей Изменение_Данных_Врачей)
        {
            InitializeComponent();
            _doctor= (o as Button).DataContext as Doctor;
            
            _ef = ef;
            _window = Изменение_Данных_Врачей;

            TxtNameDc.Text = _doctor.Name;
            TxtPhoneDc.Text = _doctor.telephone;
            TxtSpecialtyDc.Text = Convert.ToString(_doctor.specialty)
                ; 
          
            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            _ef.Doctor.Remove(_doctor);
            _ef.SaveChanges();
            _window.RefreshDoctor();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            _doctor.Name = TxtNameDc.Text;
            _doctor.telephone = TxtPhoneDc.Text;
            _doctor.specialty = TxtSpecialtyDc.Text;

            _window.RefreshDoctor();
            _ef.SaveChanges();
        }
    }
}
