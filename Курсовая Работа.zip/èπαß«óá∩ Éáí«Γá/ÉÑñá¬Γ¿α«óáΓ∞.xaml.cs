﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Курсовая_Работа
{
    /// <summary>
    /// Логика взаимодействия для Редактировать.xaml
    /// </summary>
    public partial class Редактировать : Window
    {
       private СтоматологияEntities _ef;
        private Client _client;
        private Добавление_клиента _window;
        private СтоматологияEntities ef;
        private object sender;
        private Изм_услуг изм_услуг;

        public Редактировать( СтоматологияEntities ef, object o, Добавление_клиента добавление_клиента)
        {
            InitializeComponent();
            _client = (o as Button).DataContext as Client;
            _ef = ef;
            _window = добавление_клиента;
            

            TxtNameCl.Text = _client.Name;
            TxtTeleCl.Text = Convert.ToString(_client.telephone);
           
        }

        public Редактировать(СтоматологияEntities ef, object sender, Изм_услуг изм_услуг)
        {
            this.ef = ef;
            this.sender = sender;
            this.изм_услуг = изм_услуг;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            _ef.Client.Remove(_client);
            _ef.SaveChanges();
            _window.RefreshClient();
            
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            _client.Name = TxtNameCl.Text;
            _client.telephone = TxtTeleCl.Text;

            _window.RefreshClient();
            _ef.SaveChanges();

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            _client.Name = TxtNameCl.Text;
            _client.telephone = TxtTeleCl.Text;

            _window.RefreshClient();
            _ef.SaveChanges();
        }
    }
}
