﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Курсовая_Работа
{
    /// <summary>
    /// Логика взаимодействия для Добавить_запись_на_приём.xaml
    /// </summary>
    public partial class Добавить_запись_на_приём : Window
    {
        private СтоматологияEntities _ef;
        private Записать_на_приём _window;
        public Добавить_запись_на_приём(СтоматологияEntities стоматологияEntities, Записать_на_приём записать_на_приём)
        {
            InitializeComponent();
            this._ef = стоматологияEntities;
            this._window = записать_на_приём;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            _ef.Appointment.Add(new Appointment()
            {
                date = Convert.ToDateTime(data.Text),
               ID_Doctor = Convert.ToInt32(Txtvrach.Text),
               ID_Client = Convert.ToInt32(Txtclient.Text)

            });
            _ef.SaveChanges();
            _window.RefreshAppointment();
            this.Close();
        }
    }
}
