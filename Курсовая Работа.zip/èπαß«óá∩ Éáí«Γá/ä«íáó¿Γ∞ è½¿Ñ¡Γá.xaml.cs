﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Курсовая_Работа
{
    /// <summary>
    /// Логика взаимодействия для Добавить_Клиента.xaml
    /// </summary>
    public partial class Добавить_Клиента : Window
    {
        private СтоматологияEntities _ef;
        private Добавление_клиента _window;
        public Добавить_Клиента(СтоматологияEntities стоматологияEntities , Добавление_клиента добавление_Клиента)
        {
            InitializeComponent();
            this._ef = стоматологияEntities;
            this._window = добавление_Клиента;
        }

       /*public Добавить_Клиента(СтоматологияEntities ef, Изм_услуг изм_услуг)
        {
            this.ef = ef;
            this.изм_услуг = изм_услуг;
        }*/

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            _ef.Client.Add(new Client()
            {
                Name = TxtNameCl.Text,
                telephone = TxtTeleCl.Text
            });
            _ef.SaveChanges();
            _window.RefreshClient();
            this.Close();
        }
    }
}
