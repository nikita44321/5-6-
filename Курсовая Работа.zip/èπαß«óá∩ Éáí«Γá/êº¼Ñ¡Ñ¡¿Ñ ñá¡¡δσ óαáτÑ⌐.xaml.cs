﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Курсовая_Работа
{
    /// <summary>
    /// Логика взаимодействия для Изменение_данных_врачей.xaml
    /// </summary>
    public partial class Изменение_данных_врачей : Window
    {
        public static СтоматологияEntities ef = new СтоматологияEntities();
     
        private int _currentPage = 1;
        private int _maxPage = 0;
        private СтоматологияEntities _ef;
       
        public Изменение_данных_врачей()
        {
            InitializeComponent();
            DataGridDoctor.ItemsSource = ef.Doctor.ToList();
            _ef = ef;

            RefreshDoctor();
        }
        public void RefreshDoctor()
        {
            DataGridDoctor.ItemsSource = _ef.Doctor.OrderBy(h => h.Name).ToList();
            _maxPage = Convert.ToInt32(Math.Ceiling(_ef.Doctor.ToList().Count * 1.0 / 10));
            var listDoctor = _ef.Doctor.ToList().Skip((_currentPage - 1) * 10).Take(10).ToList();
            LblTotalPages1.Content = "of" + _maxPage.ToString();
            TxtCurrentPageNumber1.Text = _currentPage.ToString();
            DataGridDoctor.ItemsSource = listDoctor;
        }
        private void GoNextPageButton1_Click(object sender, RoutedEventArgs e)
        {
            if (_currentPage + 1 < _maxPage)
            {
                return;
            }
            _currentPage = _currentPage + 1;
            //RefreshClient();
        }

        private void GoLastPageButton1_Click(object sender, RoutedEventArgs e)
        {
            _currentPage = _maxPage;
            // RefreshClient();
        }

        private void TxtCurrentPageNumber1_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (_currentPage > 0 && _currentPage < _maxPage && TxtCurrentPageNumber1.Text != "")
            {
                _currentPage = Convert.ToInt32(TxtCurrentPageNumber1.Text);
                //RefreshClient();
            }
        }

        private void GoPrevPageButton1_Click(object sender, RoutedEventArgs e)
        {
            if (_currentPage - 1 < 1)
            {
                return;
            }
            _currentPage = _currentPage - 1;
            //RefreshClient();
        }

        private void GoFirstPageButton1_Click(object sender, RoutedEventArgs e)
        {
            _currentPage = 1;
            // RefreshClient();
        }
        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            Добавить_врача добавить_врача = new Добавить_врача(_ef, this);
            добавить_врача.ShowDialog();
        }

        private void Редактировать_Click(object sender, RoutedEventArgs e)
        {
            Редактировать_изменение_данных_врачей редактировать_изменение_данных_врачей = new Редактировать_изменение_данных_врачей(_ef, sender, this);
            редактировать_изменение_данных_врачей.ShowDialog();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Главная_Админ_ pg = new Главная_Админ_();
            pg.Show();
            this.Hide();
        }
    }
}
