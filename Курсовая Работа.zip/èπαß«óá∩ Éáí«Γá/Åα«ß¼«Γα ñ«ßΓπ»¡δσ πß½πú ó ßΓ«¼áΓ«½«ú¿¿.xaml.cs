﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Курсовая_Работа
{
    /// <summary>
    /// Логика взаимодействия для Просмотр_доступных_услуг_в_стоматологии.xaml
    /// </summary>
    public partial class Просмотр_доступных_услуг_в_стоматологии : Window
    {
        public static СтоматологияEntities ef = new СтоматологияEntities();
       
        private СтоматологияEntities _ef;
        

        public Просмотр_доступных_услуг_в_стоматологии()
        {
            InitializeComponent();
            DataGridService.ItemsSource = ef.Service.ToList();

            _ef = ef;

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Главная pg = new Главная();
            pg.Show();
            this.Hide();
        }
    }
}
