﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Курсовая_Работа
{
    public partial class СтоматологияEntities
    {

        private static СтоматологияEntities entities;
        public static СтоматологияEntities GetContext()
        {
            if (entities == null)
                entities = new СтоматологияEntities();
            return entities;
        }
    }
}
