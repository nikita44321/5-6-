﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Курсовая_Работа
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        СтоматологияEntities ef;
        public MainWindow()
        {
            InitializeComponent();
            ef = new СтоматологияEntities();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                if (ef.User.Where(r => r.login == log.Text && r.password == pass.Text).Count() == 0)
                {
                    log.Text = "";
                    pass.Text = "";
                    MessageBox.Show("Неверный логин или пароль");
                }


                else
                {
                    User data = ef.User.Where(r => r.login == log.Text && r.password == pass.Text).FirstOrDefault();
                    StaticUser.user = data;
                    if (data.roli == "user")
                    {
                        MessageBox.Show("User");
                        Главная pg = new Главная();
                        pg.Show();
                        this.Hide();
                    }
                    else if (data.roli == "admin")
                    {
                        MessageBox.Show("Admin");
                        Главная_Админ_ pg = new Главная_Админ_();
                        pg.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Ошибка!");
                    }


                }
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Window1 pg = new Window1();
            pg.Show();
            this.Hide();
        }
    }

}

