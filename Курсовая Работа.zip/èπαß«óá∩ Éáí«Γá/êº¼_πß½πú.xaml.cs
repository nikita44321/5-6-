﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Курсовая_Работа
{
    /// <summary>
    /// Логика взаимодействия для Изм_услуг.xaml
    /// </summary>
    public partial class Изм_услуг : Window
    {
        public static СтоматологияEntities ef = new СтоматологияEntities();
       
        private int _currentPage = 1;
        private int _maxPage = 0;
        private СтоматологияEntities _ef;
      
        public Изм_услуг()

        {
            InitializeComponent();
            DataGridService.ItemsSource = ef.Service.ToList();
            _ef = ef;

            RefreshService();
        }
         


        public void RefreshService()
        {
            DataGridService.ItemsSource = _ef.Service.OrderBy(h => h.Name).ToList();
            _maxPage = Convert.ToInt32(Math.Ceiling(_ef.Service.ToList().Count * 1.0 / 10));
            var listService = _ef.Service.ToList().Skip((_currentPage - 1) * 10).Take(10).ToList();
            LblTotalPages1.Content = "of" + _maxPage.ToString();
            TxtCurrentPageNumber1.Text = _currentPage.ToString();
            DataGridService.ItemsSource = listService;
        }

        private void Редактировать_Click(object sender, RoutedEventArgs e)
        {
            Редактировать_изм_услуг редактировать_изм_услуг = new Редактировать_изм_услуг(_ef, sender, this);
            редактировать_изм_услуг.ShowDialog();
        }

        

        

        private void GoNextPageButton1_Click(object sender, RoutedEventArgs e)
        {
            if (_currentPage + 1 < _maxPage)
            {
                return;
            }
            _currentPage = _currentPage + 1;
            //RefreshClient();
        }

        private void GoLastPageButton1_Click(object sender, RoutedEventArgs e)
        {
            _currentPage = _maxPage;
            // RefreshClient();
        }

        private void TxtCurrentPageNumber1_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (_currentPage > 0 && _currentPage < _maxPage && TxtCurrentPageNumber1.Text != "")
            {
                _currentPage = Convert.ToInt32(TxtCurrentPageNumber1.Text);
                //RefreshClient();
            }
        }

        private void GoPrevPageButton1_Click(object sender, RoutedEventArgs e)
        {
            if (_currentPage - 1 < 1)
            {
                return;
            }
            _currentPage = _currentPage - 1;
            //RefreshClient();
        }

        private void GoFirstPageButton1_Click(object sender, RoutedEventArgs e)
        {
            _currentPage = 1;
            // RefreshClient();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            Добавление_Услуги добавление_Услуг = new Добавление_Услуги(_ef,  this);
            добавление_Услуг.ShowDialog();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Главная_Админ_ pg = new Главная_Админ_();
            pg.Show();
            this.Hide();
        }
    }
}
