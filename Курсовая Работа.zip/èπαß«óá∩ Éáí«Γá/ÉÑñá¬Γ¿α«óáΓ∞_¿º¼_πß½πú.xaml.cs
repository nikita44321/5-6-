﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Курсовая_Работа
{
    /// <summary>
    /// Логика взаимодействия для Редактировать_изм_услуг.xaml
    /// </summary>
    public partial class Редактировать_изм_услуг : Window
    {
        private СтоматологияEntities _ef;
        private Service _service;
        private Изм_услуг _window;
        private СтоматологияEntities ef;
     
        private Изм_услуг изм_услуг;
        

        public Редактировать_изм_услуг(СтоматологияEntities ef, Изм_услуг изм_услуг)
        {
            this.ef = ef;
            this.изм_услуг = изм_услуг;
        }

        public Редактировать_изм_услуг(СтоматологияEntities ef, object o, Изм_услуг изм_услуг)
        {
            InitializeComponent();
            _service = (o as Button).DataContext as Service;
           // _service = (o as Button).DataContext as Service;
            _ef = ef;
            _window = изм_услуг;

            TxtNameSr.Text = _service.Name;
            TxtPriceSr.Text = _service.price;
            TxtDescriptionSr.Text =Convert.ToString( _service.description);

        
        }
      
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            _ef.Service.Remove(_service);
            _ef.SaveChanges();
            _window.RefreshService();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            _service.Name = TxtNameSr.Text;
            _service.price = TxtPriceSr.Text;
            _service.description = TxtDescriptionSr.Text;

            _window.RefreshService();
            _ef.SaveChanges();
        }
    }
}
